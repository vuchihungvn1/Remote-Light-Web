Remote Light for Windows (portable)

1. Extract this folder to a location you control.
2. Run RemoteLight.exe.
3. Sign in directly in the Remote Light window. The app remembers your sign-in
   with Windows Credential Manager. Sign out from the account menu to clear it.
4. Scan the QR code shown in the app with your phone, or enter the six-digit code on the phone website.
5. Keep the app running while pairing from your phone.

The launcher starts the local host agent. Do not rename or remove rl-agent.exe.
