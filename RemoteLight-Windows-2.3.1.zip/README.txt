Remote Light 2.3.1
Mo RemoteLight.exe de dang nhap.
Dong cua so de thu ung dung vao khay he thong.
Nhan bieu tu de mo lai. Nhan chuot phai de ngat ket noi hoac thoat han.
