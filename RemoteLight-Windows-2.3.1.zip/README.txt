Remote Light for Windows (portable)

1. Extract this folder to a location you control.
2. Run RemoteLight.exe.
3. Sign in directly in the Remote Light window. The app remembers your sign-in
   with Windows Credential Manager. Sign out from the account menu to clear it.
4. Scan the QR code shown in the app with your phone, or enter the six-digit code on the phone website.
5. Keep the app running while pairing from your phone.

RemoteLight.exe includes the host agent.

For Pro Max screen sharing, approve the phone connection on the PC and enable
primary-screen sharing in the Remote Light window. On the phone, open screen
sharing and tap the preview to left-click. Disconnecting ends the share.

Windows can reject input to elevated applications. Handle UAC prompts on the PC.
